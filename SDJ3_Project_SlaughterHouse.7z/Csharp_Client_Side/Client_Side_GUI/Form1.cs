﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client_Side_GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //add complaints button
        private void button1_Click(object sender, EventArgs e)
        {

        }
        //compaint id box
        private void ComplaintBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //list of complaints
        private void Complaints_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //handle complaint button
        private void button2_Click(object sender, EventArgs e)
        {

        }

        //animal id box
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //animal waight box
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        //animal type box
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        //animal add button
        private void addAnimal_Click(object sender, EventArgs e)
        {

        }

        private void CuttingAnimalidBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void CutAnimalTrayidBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void CutPartidBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void CutPartTypeBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void CutPartWaightBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void CutTrayWaightTotalBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void CutButton_Click(object sender, EventArgs e)
        {

        }
    }
}
