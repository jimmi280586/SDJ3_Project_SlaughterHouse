﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Client_Side_T1_Library
{
    public class Client_Side_Controller
    {
        public void addAnimal(Animal animal)
        {

        }

        public void getAnimal(int id)
        {

        }

        public void getPart(int partId)
        {

        }

        public void addParts(Parts parts)
        {

        }

       // add tray

        public void getTray(int TrayId)
        {

        }

        public void addPartToTray(Parts parts)
        {

        }
        //addorder
        //makeorder

        public void packParts(Parts part)
        {

        }

        public void addPackage(Pack package)
        {

        }

        public void complain(int packId)
        {

        }

        public void recallPack(int packId)
        {

        }
    }
}
